import React, { useState } from "react";
import { Row, Col, Form, Button } from "react-bootstrap";

const initialData = {
  name: "",
  mobile: "",
  balance: "",
};

const Update = () => {
  const [input, setInput] = useState(initialData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setInput((prevInput) => ({ ...prevInput, [name]: value }));
  };

  return (
    <>
      <h5>Update</h5>
      <Form>
        <Row>
          <Col>
            <Form.Group className="mb-3" controlId="ControlInput1">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Name"
                name="name"
                value={input.name}
                onChange={(e) => handleChange(e)}
              />
            </Form.Group>
            <Button size="sm" variant="primary">
              Update Name
            </Button>{" "}
          </Col>
          <Col>
            <Form.Group className="mb-3" controlId="ControlInput2">
              <Form.Label>Mobile</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter Mobile"
                name="mobile"
                value={input.mobile}
                onChange={(e) => handleChange(e)}
              />
            </Form.Group>
            <Button size="sm" variant="primary">
              Update Mobile
            </Button>{" "}
          </Col>
          <Col>
            <Form.Group className="mb-3" controlId="ControlInput3">
              <Form.Label>Balance</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter Amount"
                name="balance"
                onChange={(e) => handleChange(e)}
              />
            </Form.Group>
            <Button size="sm" variant="success">
              Deposit
            </Button>{" "}
            <Button size="sm" variant="danger">
              Withdraw
            </Button>{" "}
          </Col>
        </Row>
      </Form>
    </>
  );
};

export default Update;
