import React from "react";
import { Row, Col, Table } from "react-bootstrap";
import { useSelector } from "react-redux";

const View = () => {
  const data = useSelector((state) => state);

  return (
    <>
      <h5 className="mt-4">View Data</h5>
      <Row>
        <Col>
          <Table striped bordered hover size="sm">
            <thead className="table-primary">
              <tr>
                <th>Name</th>
                <th>Mobile</th>
                <th>Balance</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{data.name}</td>
                <td>{data.mobile}</td>
                <td>{data.balance}</td>
              </tr>
            </tbody>
          </Table>
        </Col>
      </Row>
    </>
  );
};

export default View;
