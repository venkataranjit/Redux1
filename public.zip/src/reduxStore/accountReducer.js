const initialState = {
  name: "Ranjit",
  mobile: 9966189948,
  balance: 105698,
};
export const accountReducer = (state = initialState, action) => {
  return state;
};
